# Blockworld — Installable App Project

This project wraps the **original uploaded Blockworld design**. It is not a redesign. It includes the corrected `rabbit` initialization-order startup fix from the provided archive and adds an Exit Game/App control.

## What's included

- Original HTML/CSS/JavaScript first-person 3D game and pixel-style interface, preserved in `www/index.html`
- Offline-friendly local copies of Three.js and PeerJS **after** `npm install` and `npm run prepare:web`
- Capacitor configuration for Android and iOS
- Electron desktop wrapper with isolated/sandboxed game view and Quit action
- GitHub Actions that generate an Android debug `.apk`, Windows `.exe`, and unsigned Mac `.dmg`
- Generated voxel app icon and optional splash image

**This ZIP is the build-ready source project, not an already compiled APK/EXE/DMG.** This execution environment cannot access npm packages or an Android SDK, so no compiled native artifact is included. The workflows compile binaries on GitHub-hosted builders.

## Quick start (Windows, Mac, Linux)

1. Install Node.js 22 or newer and unzip this project.
2. Open a terminal in the folder containing `package.json`.
3. Run:

```sh
npm install
npm run prepare:web
npm run dev
```

Open http://localhost:8080 to try the locally bundled game. You may run `npm run desktop` to test the app in Electron. The game assets are procedural; external optional media/links still need internet.

## Android (APK)

Install Android Studio, SDK and JDK 21 (Android Studio typically provides the required tools). Then run:

```sh
npm install
npm run android:add
npm run android:icons
npm run android:sync
```

Open the generated `android/` folder in Android Studio, or run `cd android` and `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`). The output is:

`android/app/build/outputs/apk/debug/app-debug.apk`

This **debug-signed APK** is suitable for sideload testing. For a store-ready release, build and sign a release variant using your own keystore and follow Google Play requirements.

### Without a computer: GitHub Actions

Create a repository on GitHub, upload the **contents** of this ZIP (including `.github/workflows`), then choose Actions → **Android APK** → Run workflow. After the run completes, open its **Artifacts** section to download `Blockworld-Android-APK`. Extract that artifact ZIP to get `app-debug.apk`.

The workflow depends on npm and the Android SDK provided by the GitHub runner. If GitHub's Android tooling changes, update the workflow accordingly. It has not been run in this environment.

## Windows installer (.exe)

On Windows with Node.js installed:

```powershell
npm install
npm run build:windows
```

Output: `release/Blockworld-Setup-1.0.0.exe`

## Mac app / DMG

On a Mac with Node.js:

```sh
npm install
npm run build:mac
```

Output: `release/Blockworld-1.0.0-<architecture>.dmg`. Mount the DMG to access the `.app`. Unsigned Mac apps may be blocked by Gatekeeper; signed/notarized distribution is recommended.

## iPhone

Requires macOS, Xcode and an Apple developer signing identity for distribution:

```sh
npm install
npm run ios:add
npm run ios:sync
npx cap open ios
```

Select your team in Signing & Capabilities, then Product → Archive in Xcode. The signed iOS app can be distributed via TestFlight/App Store. Apple does not use an ordinary shareable `.app` file for iPhone installation.

## Key files

| File | Description |
|---|---|
| `www/index.html` | Complete original game plus native Exit control |
| `www/vendor/*` | Created by `npm run prepare:web`; **not included** in source ZIP |
| `electron/main.cjs` | Sandboxed Electron main process, loads local game |
| `electron/preload.cjs` | Exposes only one restricted Quit operation |
| `capacitor.config.json` | Android/iOS app identity and web directory |
| `scripts/prepare-web.mjs` | Copies pinned JS graphics/network dependencies into the app |
| `.github/workflows/` | Remote Android, Windows and Mac builds |
| `assets/icon.png`, `.ico`, `.icns` | Pixel-art launcher assets for Android, Windows and Mac |

## Exit behavior

The pause screen's **Exit Game / App** button saves and quits the running world. It closes the installed Windows/Mac app via Electron; on Android it attempts to close via Capacitor App plugin; on iOS it safely returns to the title screen, consistent with iOS conventions.

## Important limitations

- The game renderer and network library are bundled offline **only after running the npm preparation step**.
- Multiplayer is peer-to-peer and needs a live internet connection and an active host. Other advanced game systems are not fully synchronized.
- Local saves are per-device, not cloud synchronized.
- The provided public Netlify URL has not been verified by this environment. Bundling this local app does not change the published Netlify site.
- Full native Android/iOS/Windows/macOS builds and real-device multiplayer have **not** been validated here.
- App package IDs and signing certificates must be personalized before public store publication.

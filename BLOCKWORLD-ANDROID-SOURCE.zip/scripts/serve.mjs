import http from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const web = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'www');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    const name = decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname);
    const dest = path.resolve(web, '.' + name);
    if (!dest.startsWith(web + path.sep)) { res.writeHead(403).end(); return; }
    const data = await readFile(dest);
    res.setHeader('Content-Type', (mime[path.extname(dest)] || 'application/octet-stream') + '; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store');
    res.end(data);
  } catch (error) { res.writeHead(404).end('Not found'); }
}).listen(8080, '127.0.0.1', () => console.log('Blockworld: http://localhost:8080'));

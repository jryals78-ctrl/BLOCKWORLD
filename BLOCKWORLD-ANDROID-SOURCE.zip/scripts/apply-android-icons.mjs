import { cpSync, existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const android=path.join(root,'android','app','src','main','res');
if(!existsSync(android))throw new Error('Run npm run android:add first');
for (const dpi of ['mdpi','hdpi','xhdpi','xxhdpi','xxxhdpi']) {
 for (const name of ['ic_launcher.png','ic_launcher_round.png']) {
  cpSync(path.join(root,'assets','android-icons',`mipmap-${dpi}`,name),path.join(android,`mipmap-${dpi}`,name));
 }
}
console.log('Original-style launcher icon applied to Android mipmap assets.');

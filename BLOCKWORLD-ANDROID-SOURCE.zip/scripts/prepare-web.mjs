import { copyFileSync, existsSync, mkdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const vendor = path.join(root, 'www', 'vendor');
mkdirSync(vendor, { recursive: true });
for (const [name, options] of Object.entries({
  'three.min.js': ['node_modules/three/build/three.min.js'],
  'peerjs.min.js': ['node_modules/peerjs/dist/peerjs.min.js', 'node_modules/peerjs/dist/peerjs.js']
})) {
  const found = options.map(x => path.join(root, x)).find(existsSync);
  if (!found) throw new Error(`Missing ${name}. Run npm install in the project folder.`);
  const dst = path.join(vendor, name);
  copyFileSync(found, dst);
  console.log(`Bundled ${name}: ${statSync(dst).size} bytes`);
}
console.log('App runtime is self-contained for offline solo play. Multiplayer requires internet.');

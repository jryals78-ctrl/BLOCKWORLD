import { readFileSync, existsSync, statSync } from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const html = readFileSync(path.join(root, 'www/index.html'), 'utf8');
function assert(ok, what) { if (!ok) throw new Error(what); console.log('PASS',what); }
assert(html.includes('Host Multiplayer World') && html.includes('Join Multiplayer Room'), 'Original multiplayer menu exists');
assert(html.includes('Exit Game / App'), 'Exit Game control exists');
assert(html.includes('BASESP') && html.includes("t:'rabbit'"), 'Original creature definitions included');
assert(html.indexOf('BASESP.forEach') > html.indexOf('var MDROP='), 'Mob drop settings initialized before rabbit registration');
assert(html.includes('./vendor/three.min.js') && html.includes('./vendor/peerjs.min.js'), 'App uses local JS dependencies');
const scripts = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)].map(m => m[1]).filter(Boolean);
for(let i=0;i<scripts.length;i++)new vm.Script(scripts[i], { filename: `index.inline.${i}.js` });
assert(scripts.length > 0, 'Inline scripts parse without syntax errors');
if(process.argv.includes('--bundled')) {
 for(const fn of ['three.min.js','peerjs.min.js']) {
  const p=path.join(root,'www/vendor',fn);
  assert(existsSync(p) && statSync(p).size > 10000, `${fn} bundled successfully`);
 }
}
console.log('BLOCKWORLD PREFLIGHT COMPLETE');

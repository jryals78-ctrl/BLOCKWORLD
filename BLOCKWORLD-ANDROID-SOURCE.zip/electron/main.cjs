const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('node:path');
const { URL } = require('node:url');

function createWindow() {
  const win = new BrowserWindow({
    title: 'BLOCKWORLD', width: 1160, height: 760,
    minWidth: 670, minHeight: 450, backgroundColor: '#78b7f0',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      nodeIntegration: false, contextIsolation: true,
      sandbox: true, webSecurity: true, webviewTag: false
    }
  });
  win.loadFile(path.join(__dirname, '..', 'www', 'index.html'));
  win.webContents.setWindowOpenHandler(({ url }) => {
    try { if (new URL(url).protocol === 'https:') shell.openExternal(url); } catch (_) {}
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (event, url) => {
    if (!url.startsWith('file://')) event.preventDefault();
  });
}
app.whenReady().then(() => {
  ipcMain.on('blockworld:quit', () => app.quit());
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => app.quit());

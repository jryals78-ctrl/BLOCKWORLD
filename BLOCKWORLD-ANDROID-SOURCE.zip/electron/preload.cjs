const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('BlockworldBridge', Object.freeze({
  isDesktop: true,
  quit: () => ipcRenderer.send('blockworld:quit')
}));
